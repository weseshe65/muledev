# Home

The Custom Message Logging policy enables you to log a custom message with the information available from policies, a proxy, or the backend, at any point of the execution.

## Additional References

- [Policies in Mule 4](https://docs.mulesoft.com/api-manager/2.x/policies-mule4)